from django.db import migrations


CURATED_TOPICS = [
    "Neuroscience",
    "Cognitive Neuroscience",
    "Computational Neuroscience",
    "Neuroimaging",
    "Brain-Computer Interfaces",
    "Neural Engineering",
    "Neurotechnology",
    "Cognitive Science",
    "Psychology",
    "Behavioral Science",
    "Digital Health",
    "Mental Health Research",
    "Clinical Research",
    "Biostatistics",
    "Bioinformatics",
    "Systems Biology",
    "Genomics",
    "Biomedical Engineering",
    "Medical Imaging",
    "Public Health",
    "Epidemiology",
    "Ethics in AI",
    "Responsible AI",
    "AI Safety",
    "Trustworthy AI",
    "Explainable AI",
    "Machine Learning",
    "Deep Learning",
    "Natural Language Processing",
    "Computer Vision",
    "Reinforcement Learning",
    "Robotics",
    "Human-Computer Interaction",
    "Federated Learning",
    "Privacy",
    "Differential Privacy",
    "Cybersecurity",
    "Data Governance",
    "Data Science",
    "Causal Inference",
    "Statistics",
    "Optimization",
    "Signal Processing",
    "Wearable Sensors",
    "Assistive Technologies",
    "Health Informatics",
    "Scientific Reproducibility",
    "Open Science",
    "Research Methods",
    "Innovation in Healthcare",
]


def seed_curated_topics(apps, schema_editor):
    Tag = apps.get_model("tags", "Tag")
    Event = apps.get_model("events", "Event")
    EventTag = Event.tags.through

    neuroscience_tag = Tag.objects.filter(name__iexact="Neuroscience").first()
    duplicate_tag = Tag.objects.filter(name__iexact="Neurosciences").first()

    if duplicate_tag and neuroscience_tag and duplicate_tag.pk != neuroscience_tag.pk:
        for relation in EventTag.objects.filter(tag_id=duplicate_tag.pk).iterator():
            EventTag.objects.get_or_create(event_id=relation.event_id, tag_id=neuroscience_tag.pk)
        EventTag.objects.filter(tag_id=duplicate_tag.pk).delete()
        duplicate_tag.delete()
    elif duplicate_tag and not neuroscience_tag:
        duplicate_tag.name = "Neuroscience"
        duplicate_tag.save(update_fields=["name"])

    keep_ids = []
    for topic in CURATED_TOPICS:
        tag = Tag.objects.filter(name__iexact=topic).first()
        if tag:
            if tag.name != topic:
                tag.name = topic
                tag.save(update_fields=["name"])
        else:
            tag = Tag.objects.create(name=topic)
        keep_ids.append(tag.pk)

    Tag.objects.exclude(pk__in=keep_ids).delete()


def noop_reverse(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ("events", "0003_event_banner"),
        ("tags", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(seed_curated_topics, noop_reverse),
    ]
